from airflow import DAG


# 根据输入材料补全发布窗口复核DAG。最终文件需保留真实Pool声明、setup任务和teardown任务。
dag = DAG(dag_id="shared_gpu_release_rehearsal", schedule=None, catchup=False)
